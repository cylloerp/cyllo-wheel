cache_aligned_allocator.o: \
 ../tbb_2020.3/src/tbb/cache_aligned_allocator.cpp \
 ../tbb_2020.3/include/tbb/tbb_config.h \
 ../tbb_2020.3/include/tbb/cache_aligned_allocator.h \
 ../tbb_2020.3/include/tbb/tbb_stddef.h \
 ../tbb_2020.3/include/tbb/tbb_config.h \
 ../tbb_2020.3/include/tbb/tbb_allocator.h \
 ../tbb_2020.3/include/tbb/tbb_exception.h \
 ../tbb_2020.3/include/tbb/internal/_warning_suppress_enable_notice.h \
 ../tbb_2020.3/include/tbb/internal/../tbb_config.h \
 ../tbb_2020.3/include/tbb/tbb_allocator.h \
 ../tbb_2020.3/include/tbb/internal/_warning_suppress_disable_notice.h \
 ../tbb_2020.3/src/tbb/tbb_misc.h ../tbb_2020.3/include/tbb/tbb_stddef.h \
 ../tbb_2020.3/include/tbb/tbb_machine.h \
 ../tbb_2020.3/include/tbb/machine/gcc_generic.h \
 ../tbb_2020.3/include/tbb/machine/gcc_ia32_common.h \
 ../tbb_2020.3/include/tbb/machine/gcc_itsx.h \
 ../tbb_2020.3/include/tbb/machine/linux_common.h \
 ../tbb_2020.3/include/tbb/atomic.h \
 ../tbb_2020.3/include/tbb/internal/_deprecated_header_message_guard.h \
 ../tbb_2020.3/include/tbb/tbb_machine.h ../tbb_2020.3/include/tbb/info.h \
 ../tbb_2020.3/src/tbb/dynamic_link.h
