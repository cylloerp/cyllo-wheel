spin_rw_mutex_v2.o: ../tbb_2020.3/src/old/spin_rw_mutex_v2.cpp \
 ../tbb_2020.3/src/old/spin_rw_mutex_v2.h \
 ../tbb_2020.3/include/tbb/tbb_stddef.h \
 ../tbb_2020.3/include/tbb/tbb_config.h \
 ../tbb_2020.3/include/tbb/tbb_machine.h \
 ../tbb_2020.3/include/tbb/tbb_stddef.h \
 ../tbb_2020.3/include/tbb/machine/gcc_generic.h \
 ../tbb_2020.3/include/tbb/machine/gcc_ia32_common.h \
 ../tbb_2020.3/include/tbb/machine/gcc_itsx.h \
 ../tbb_2020.3/include/tbb/machine/linux_common.h \
 ../tbb_2020.3/src/old/../tbb/itt_notify.h \
 ../tbb_2020.3/src/old/../tbb/tools_api/ittnotify.h \
 ../tbb_2020.3/src/old/../tbb/tools_api/legacy/ittnotify.h \
 ../tbb_2020.3/include/tbb/atomic.h \
 ../tbb_2020.3/include/tbb/internal/_deprecated_header_message_guard.h \
 ../tbb_2020.3/include/tbb/tbb_config.h \
 ../tbb_2020.3/include/tbb/internal/_warning_suppress_enable_notice.h \
 ../tbb_2020.3/include/tbb/internal/../tbb_config.h \
 ../tbb_2020.3/include/tbb/tbb_machine.h \
 ../tbb_2020.3/include/tbb/internal/_warning_suppress_disable_notice.h
